.. modem documentation master file, created by
   sphinx-quickstart on Wed Apr 21 11:03:20 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Modem package
=============

.. automodule:: modem
   :members:

