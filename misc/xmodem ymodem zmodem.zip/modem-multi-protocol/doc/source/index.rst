.. XMODEM documentation master file, created by
   sphinx-quickstart on Wed Apr 21 11:03:20 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: about.rst

Contents
========

.. toctree::
   :maxdepth: 2

   about
   modem
   modem/const
   modem/tools

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

